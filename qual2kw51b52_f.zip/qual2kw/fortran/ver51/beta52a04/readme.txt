Aug 29, 2004

Visual FORTRAN 6.6 (latest version of Compaq FORTRAN compiler)

UPDATE QUAL2K1.3

a few changes: 
1. update Julian year in classDate

2. Weir Width (not yet)

3. fast pHsolver in derivs by remember the old value (not yet)

4. FILE NAME CHANGED: solarRadiation.f90 --> classSolarCalc.f90

					  solarposition.f90  --> classSolarPosition.f90
					 
						sourceinbackup.f90 --> ClassSrcIn.f90

						classintegration1.f90-->classintegral.f90
5. seperate ClassIntegrationData from ClassIntegral.f90 and made
	ClassIntegralData.f90
6. duplicate os and Hydrau%reach(i)%os ???



Sep 05, 2004

QUAL2K
update version 1.3 to have some of the structure of version 2.0
1. Class_Reach, Class_RiverTopo  Successfully compiled!

2. add Class_Downstream, ADD NumdatPnt the data type to accormadate number of datapoints

3. Class_Headwater make data array one dimensinal. therefore, every headwater of the tributary
	is a object. 
4. Class_Meteo

5.

Sep 09, 2004

1. add weir width
2. new solarcalculation by Greg
3. bottom algae excretion rate 

	SUBROUTINE AllocateReachArray(Topo, nRch)

		TYPE(RiverTopo_type) Topo
		INTEGER(I2B), INTENT(IN) :: nRch
		INTEGER(I2B) status
		IF (.NOT. ASSOCIATED(Topo%reach)) THEN
			IF (nRch>0)THEN
				Topo%nr = nRch
				ALLOCATE (Topo%reach(0:Topo%nr), STAT=status)
				IF (status==1) THEN 
					STOP 'Class_River:AllocateReachArray failed. Insufficient Memory!'
				END IF

			ELSE
				PRINT *, 'ERROR:element and reach number must be great than 0'
				STOP 'Class_River:AllocateReachArray failed'
			END IF
		ELSE
			PRINT *, 'Warning: River array can only allocate once. Allocation failed!'
		END IF

	END SUBROUTINE AllocateReachArray

!	SUBROUTINE AllocateElementArray(nElem)
!		INTEGER(I2B), INTENT(IN) :: nElem
!		INTEGER(I2B) status

!		IF (.NOT. ASSOCIATED(Topo%elems)) THEN
!			IF (nElem>0)THEN
!				Topo%ne = nElem
!				ALLOCATE (Topo%elems (0:Topo%ne), STAT=status)
!				IF (status==1) THEN 
!					STOP 'Class_River:AllocateReachArray failed. Insufficient Memory!'
!				END IF
!			ELSE
!				PRINT *, 'ERROR:element and reach number must be great than 0'
!				STOP 'Class_River:AllocateElementArray failed'
!			END IF
!		ELSE
!			PRINT *, 'Warning: Topo array can only allocate once. Allocation failed!'
!		END IF

!	END SUBROUTINE AllocateElementArray

	!dynamic data types
